﻿import random
import json
import os

from pico2d import *
from array import *
import game_framework
import title_state

global flag
flag = 0
name = "MainState"

boy = None
grass = None
font = None
tile = None

class Tile:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.color = 0

#tile = []
#tile.append(Tile())

mapx = [0]*20
mapy = [0]*15
for i in range(20):
    mapx[i] = i*40 + 40

for j in range(15):
    mapy[j] = j * 40 + 40



list = []

for i in range(0,15):
    list.append([])
    for j in range(0,20):
        list[i].append(Tile())


for i in range(0,15):
    for j in range(0,20):
        list[i][j].x = 40 * j + 40;
        list[i][j].y = 40 * i + 40;
        list[i][j].color = 0
print(list[12][11].color)
list[3][2].color = 2
class Grass:
    def __init__(self):
        self.color = 0
        self.image = load_image('캐릭터1.png')
        self.image1 = load_image('파랑물약.png')
        #self.image.clip_draw(self.frame * 40, self.state*(self.dir * 40), 40, 40, self.x, self.y)

    def draw(self):
        self.image.clip_draw(list[3][2].color *40,0,40,40,list[3][2].x, list[3][2].y)
        if flag == 0:
            self.image1.draw(300,30)
        #self.image.draw(400, 40)
        #self.image1.draw(300,20)

class BackGround:
    def __init__(self):
        self.image = load_image('바탕.png')
        self.color = 1

    def draw(self):
        self.image.draw(400, 300)

class Boy:
    global grass
    #global tile
    LEFT_RUN, RIGHT_RUN, LEFT_STAND, RIGHT_STAND = 0, 1, 2, 3
    def handle_left_run(self):
        global flag2
        self.x -= 5
        self.run_frames += 1
        if self.x < 0:
            self.state = self.RIGHT_RUN
            self.x = 0
       
       

    def handle_left_stand(self):
        # self.stand_frames += 1
        # if self.stand_frames == 50:
        if(flag1 == True):
            self.state = self.LEFT_RUN
            self.run_frames = 0


    def handle_right_run(self):
        global flag2
       
        #self.x += 5
        #self.run_frames += 1
        #if self.x > 800:
        #    self.state = self.LEFT_RUN
        #    self.x = 800
        #if self.run_frames == 100:
        #    self.state = self.RIGHT_STAND
        #    self.stand_frames = 0
        #if (flag2 == True):
        #    self.boost += 1
        #    self.x += 7
        #    if(self.boost > 5):
        #        flag2 = False
        #        self.boost = 0


    def handle_right_stand(self):
        #self.stand_frames += 1
        # events = get_events()
        # for event in events:
        #     if event.type == SDL_QUIT:
        #         game_framework.quit()
        #     elif (event.type == SDL_KEYDOWN):
        # if(self.flag == False):
        #     self.stand_frames += 1
        # else:
        if(flag1 == True):
            self.state = self.RIGHT_RUN
            self.run_frames = 0




    handle_state = {
        LEFT_RUN : handle_left_run,
        RIGHT_RUN: handle_right_run,
        LEFT_STAND: handle_left_stand,
        RIGHT_STAND: handle_right_stand
    }
    def __init__(self):
        self.x, self.y = 0, 90
        self.state = self.RIGHT_RUN
        self.frame = 0
        self.colorframe = 0;
        self.run_frames = 0
        self.stand_frames = 0
        self.image = load_image('캐릭터10.png')
        self.dir = 3
        self.boost = 0
        self.flag = False
        self.color = 0

    def setCheck(self,check):
        self.flag = check

    def update(self):
        self.frame = (self.frame + 1) % 2
        self.handle_state[self.state](self)

    def draw(self):
        self.image.clip_draw((self.frame + self.colorframe) * 40, self.state*(self.dir * 40), 40, 40, self.x, self.y)

def enter():
    global boy, grass, tile, background
    boy = Boy()
    grass = Grass()
    tile = Tile()
    background = BackGround()


def exit():
    global boy, grass
    del(boy)
    del(grass)


def pause():
    pass


def resume():
    pass


def handle_events():
    global boy
    global flag1
    global flag2
    global flag
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            game_framework.change_state(title_state)
        elif event.type == SDL_KEYDOWN and event.key == SDLK_RIGHT:
            boy.x += 10
            boy.dir = 2
            if boy.x > 260:
                boy.colorframe = 2
                flag = 1
        elif event.type == SDL_KEYDOWN and event.key == SDLK_LEFT:
            boy.x -= 10
            boy.dir = 0
        elif event.type == SDL_KEYDOWN and event.key == SDLK_UP:
            boy.y += 10
            boy.dir = 1
            if boy.y > list[2][2].y:
                if boy.colorframe != list[3][2].color:
                    boy.y -= 10
        elif event.type == SDL_KEYDOWN and event.key == SDLK_DOWN:
            boy.y -= 10
            boy.dir = 3
            





def update():
    boy.update()

def draw():
    clear_canvas()
    background.draw()
    grass.draw()
    boy.draw()
    update_canvas()
    delay(0.08)





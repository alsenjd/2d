#include <math.h>
#include <stdio.h>
#include <windows.h>
#include <time.h>
#include "resource.h"
#include "cSprite.h"
#define BSIZE 15
#define WIDTH 19
#define HEIGHT 14
using namespace std;
int flag = 0;
HINSTANCE g_hInst;
HINSTANCE g_hInst2;
//HDC hdc;
LPCTSTR lpszClass = "windows";
LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgProc(HWND, UINT, WPARAM, LPARAM);
static HDC hdc, memdc;
cSprite* g_pSprite = NULL;
cSprite* g_pPlayerSprite = NULL;
int m_playerstate = 0;
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;
	g_hInst2 = hInstance;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = (WNDPROC)WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = MAKEINTRESOURCE(IDR_MENU1);
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);
	hWnd = CreateWindow(lpszClass, lpszClass, (WS_OVERLAPPEDWINDOW | CW_USEDEFAULT | CW_USEDEFAULT),
		100, 100, 850, 650,
		NULL, (HMENU)NULL,
		hInstance, NULL);
	ShowWindow(hWnd, nCmdShow); UpdateWindow(hWnd);
	//hAcc = LoadAccelerators(g_hInst, MAKEINTRESOURCE(IDR_ACCELERATOR1));
	while (GetMessage(&Message, 0, 0, 0))
	{

		TranslateMessage(&Message);
		DispatchMessage(&Message);

	}
	return Message.wParam;
}
double LengthPts(double x1, double y1, double x2, double y2)
{
	return(sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1)));
}

BOOL InCircle(int x, int y, int mx, int my)
{
	if (LengthPts(x, y, mx, my) < BSIZE)
		return TRUE;
	else return FALSE;
}
typedef struct Tile{
	int x;
	int y;
	int type;
}TILE;
RECT rect[WIDTH][HEIGHT];
TILE tile[WIDTH][HEIGHT];
bool a;
bool Selection = false;
int num = 0;

RECT rcClient;
HDC hmemdc;
HBITMAP hbmp;
void BackBuffSetting(HDC hdc, HWND hWnd);
void Draw(HDC hdc, HWND hWnd);
HBITMAP hBitmap, hBitmap1, hBitmap2, hBitmap3, hBitmap4, hBitmap5, hBitmap6, hBitmap7, hBitmap8;
HWND hButton;
int Type;
FILE* fp;
LRESULT CALLBACK WndProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	HWND hDlg = NULL;
	srand(unsigned(time(NULL)));
	static HINSTANCE hInstance;
	PAINTSTRUCT ps;
	static int x, y, Dir;
	switch (iMsg)
	{
	case WM_CREATE:

		SetTimer(hWnd, 0, 30, NULL);
		for (int i = 0; i < HEIGHT; i++)
		{
			for (int j = 0; j < WIDTH; j++)
			{
				tile[j][i].x = 40 * j;
				tile[j][i].y = 40 * i;

				rect[j][i].top = i * 40;
				rect[j][i].left = j * 40;
				rect[j][i].bottom = rect[j][i].top + 40;
				rect[j][i].right = rect[j][i].left + 40;;
				
			}
		}
		if (g_pSprite == NULL)
		{
			g_pSprite = new cSprite;
			g_pSprite->InitSprite(hdc, g_hInst, 0, "res/object.bmp", 40, 40);
			g_pSprite->InitSprite(hdc, g_hInst, 1, "res/blue.bmp", 40, 40);
			g_pSprite->InitSprite(hdc, g_hInst, 2, "res/red.bmp", 40, 40);
			g_pSprite->InitSprite(hdc, g_hInst, 3, "res/yellow.bmp", 40, 40);
			g_pSprite->InitSprite(hdc, g_hInst, 4, "res/bluewall.bmp", 40, 40);
			g_pSprite->InitSprite(hdc, g_hInst, 5, "res/redwall.bmp", 40, 40);
			g_pSprite->InitSprite(hdc, g_hInst, 6, "res/yellowwall.bmp", 40, 40);
			g_pSprite->InitSprite(hdc, g_hInst, 7, "res/����2.bmp", 40, 40);
			g_pSprite->InitSprite(hdc, g_hInst, 8, "res/�ⱸ.bmp", 40, 40);

		}

		break;
	case WM_CHAR:
		break;
	case WM_TIMER:
		InvalidateRect(hWnd, NULL, false);
		break;
	case WM_PAINT:


		hdc = BeginPaint(hWnd, &ps);
		Draw(hdc, hWnd);
		EndPaint(hWnd, &ps);

		break;
	case WM_LBUTTONDOWN:
		y = HIWORD(lParam);
		x = LOWORD(lParam);
		for (int i = 0; i < HEIGHT; i++)
		{
			for (int j = 0; j < WIDTH; j++)
			{
				if (InCircle(x, y, (tile[j][i].x + tile[j][i].x + 40) / 2, (tile[j][i].y + tile[j][i].y + 40) / 2))
				{
					if (Type == 0)
						tile[j][i].type = 0;
					else if (Type == 1)
						tile[j][i].type = 1;
					else if (Type == 2)
						tile[j][i].type = 2;
					else if (Type == 3)
						tile[j][i].type = 3;
					else if (Type == 4)
						tile[j][i].type = 4;
					else if (Type == 5)
						tile[j][i].type = 5;
					else if (Type == 6)
						tile[j][i].type = 6;
					else if (Type == 7)
						tile[j][i].type = 7;
					else if (Type == 8)
						tile[j][i].type = 8;
				}
			}
		}

		InvalidateRect(hWnd, NULL, TRUE);
		break;
	case WM_LBUTTONUP:
		break;
	case WM_COMMAND:
		//hdc = GetDC(hWnd);
		switch (LOWORD(wParam))
		{
		case ID_DLG_OPEN:
			if (!IsWindow(hDlg))
			{
				hDlg = CreateDialog(g_hInst, MAKEINTRESOURCE(IDD_DIALOG2), hWnd, DlgProc);

				ShowWindow(hDlg, SW_SHOW);

			}
		case ID_SAVE_SAVE:
			fopen_s(&fp, "test1.txt", "w");

			for (int i = 0; i < HEIGHT; i++)
			{
				for (int j = 0; j < WIDTH; j++)
				{
					fprintf(fp, "%d", tile[j][i].type);
					fprintf(fp, "\n");
				}
			}
			fclose(fp);
			break;
		}
		//ReleaseDC(hWnd, hdc);

		break;
	case WM_KEYUP:
		switch (wParam)
		{
		case VK_LEFT:
		case VK_RIGHT:
		case VK_UP:
		case VK_DOWN:
			break;
		}

		break;
	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_LEFT:
			break;
		case VK_RIGHT:
			break;
		case VK_UP:
			break;
		case VK_DOWN:
			break;
		}

		break;


	case WM_DESTROY:
		HideCaret(hWnd);
		DestroyCaret();
		PostQuitMessage(0);
		break;
	}

	return(DefWindowProc(hWnd, iMsg, wParam, lParam));
}
BOOL CALLBACK DlgProc(HWND hDlg, UINT iMsg,
	WPARAM wParam, LPARAM lParam) // ��ȭ���� �޽��� ó���Լ�
{
	switch (iMsg){
	case WM_INITDIALOG:
		hBitmap = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP3));
		hButton = GetDlgItem(hDlg, IDC_BUTTON1);
		SendMessage(hButton, BM_SETIMAGE, 0, (LPARAM)hBitmap);
		hBitmap1 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP1));
		hButton = GetDlgItem(hDlg, IDC_BUTTON2);
		SendMessage(hButton, BM_SETIMAGE, 0, (LPARAM)hBitmap1);
		hBitmap2 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP8));
		hButton = GetDlgItem(hDlg, IDC_BUTTON3);
		SendMessage(hButton, BM_SETIMAGE, 0, (LPARAM)hBitmap2);
		hBitmap3 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP10));
		hButton = GetDlgItem(hDlg, IDC_BUTTON4);
		SendMessage(hButton, BM_SETIMAGE, 0, (LPARAM)hBitmap3);
		hBitmap4 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP2));
		hButton = GetDlgItem(hDlg, IDC_BUTTON5);
		SendMessage(hButton, BM_SETIMAGE, 0, (LPARAM)hBitmap4);
		hBitmap5 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP9));
		hButton = GetDlgItem(hDlg, IDC_BUTTON6);
		SendMessage(hButton, BM_SETIMAGE, 0, (LPARAM)hBitmap5);
		hBitmap6 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP11));
		hButton = GetDlgItem(hDlg, IDC_BUTTON7);
		SendMessage(hButton, BM_SETIMAGE, 0, (LPARAM)hBitmap6);
		hBitmap7 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP12));
		hButton = GetDlgItem(hDlg, IDC_BUTTON8);
		SendMessage(hButton, BM_SETIMAGE, 0, (LPARAM)hBitmap7);
		hBitmap8 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP13));
		hButton = GetDlgItem(hDlg, IDC_BUTTON9);
		SendMessage(hButton, BM_SETIMAGE, 0, (LPARAM)hBitmap8);
		return true;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDC_BUTTON1: // ��ư
			Type = 0;
			break;
		case IDC_BUTTON2: // ��ư
			Type = 1;
			break;
		case IDC_BUTTON3: // ��ư
			Type = 2;
			break;
		case IDC_BUTTON4: // ��ư
			Type = 3;
			break;
		case IDC_BUTTON5: // ��ư
			Type = 4;
			break;
		case IDC_BUTTON6: // ��ư
			Type = 5;
			break;
		case IDC_BUTTON7: // ��ư
			Type = 6;
			break;
		case IDC_BUTTON8: // ��ư
			Type = 7;
			break;
		case IDC_BUTTON9: // ��ư
			Type = 8;
			break;
		case IDCANCEL: // ��ư
			EndDialog(hDlg, 0);
			break;
		}
		break;
	}
	return 0;
}
void Draw(HDC hdc, HWND hWnd)
{

	BackBuffSetting(hdc, hWnd);
	FillRect(hmemdc, &rcClient, (HBRUSH)GetStockObject(WHITE_BRUSH));
	RECT a1 = { 0, 0, 200, 200 };
	char a2[1000] = { 0, };
	DrawText(hmemdc, a2, -1, &a1, NULL);
	for (int i = 0; i < HEIGHT; i++)
	{
		for (int j = 0; j < WIDTH; j++)
		{

			g_pSprite->Draw(hmemdc, tile[j][i].type, tile[j][i].x, tile[j][i].y);
			//Rectangle(hmemdc, rect[j][i].left, rect[j][i].top, rect[j][i].right, rect[j][i].bottom);

		}
	}

	BitBlt(hdc, 0, 0, rcClient.right, rcClient.bottom, hmemdc, 0, 0, SRCCOPY);
	DeleteObject(hbmp);
	DeleteDC(hmemdc);
}
void BackBuffSetting(HDC hdc, HWND hWnd)
{
	GetClientRect(hWnd, &rcClient);
	hmemdc = CreateCompatibleDC(hdc);

	hbmp = CreateCompatibleBitmap(hdc, rcClient.right, rcClient.bottom);
	SelectObject(hmemdc, hbmp);
}

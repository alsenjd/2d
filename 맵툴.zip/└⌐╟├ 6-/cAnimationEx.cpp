#include "cAnimationEx.h"

cAnimationEx::cAnimationEx()
{
}
cAnimationEx::~cAnimationEx()
{
	for(int i =0 ; i < v_dc.size();i++)
		DeleteDC(v_dc.at(i));
	v_An.clear();
	v_map.clear();
	v_dc.clear();

}
void cAnimationEx::InitAnimationEx(HDC _hdc,HINSTANCE _hInst, int _number, const char *_teg,int _max,int _x ,int _y, int _start, int _end, float _time)
{
	
	m_An.max = _max;
	m_An.x = _x / _max;
	m_An.y = _y;
	m_An.start = _start;
	m_An.tempstart = _start;
	m_An.end   = _end;
	m_An.time  = _time;
	m_An.dwTime = GetTickCount();
	v_An.push_back(m_An);
	v_map.push_back((HBITMAP)LoadImage(_hInst,_teg,IMAGE_BITMAP,0,0,LR_LOADFROMFILE));
	v_dc.push_back(CreateCompatibleDC(_hdc));	
	SelectObject(v_dc.at(_number),v_map.at(_number));
}
void cAnimationEx::DrawAnimationEx(HDC _hdc, int _number, int _x, int _y)
{
	TimeCheck(_number);

	BitBlt(_hdc,_x,_y,v_An.at(_number).x,v_An.at(_number).y,
		v_dc.at(_number),v_An.at(_number).x * (v_An.at(_number).start),0,SRCCOPY);
}
void cAnimationEx::DrawAnimationEx(HDC _hdc,int _number,int _x,int _y,UINT _rgb)
{
	TimeCheck(_number);
	TransparentBlt(_hdc,_x,_y,v_An.at(_number).x,v_An.at(_number).y,
		v_dc.at(_number),v_An.at(_number).x * (v_An.at(_number).start),0,v_An.at(_number).x,v_An.at(_number).y,_rgb);
}
void cAnimationEx::TimeCheck(int _number)
{
	if(v_An.at(_number).dwTime + v_An.at(_number).time * 1000 < GetTickCount())
	{
		v_An.at(_number).start++;
		if(v_An.at(_number).start > v_An.at(_number).end)
			v_An.at(_number).start = v_An.at(_number).tempstart;
		v_An.at(_number).dwTime = GetTickCount();
	}
}

#ifndef _CANIMATIONEX_H
#define _CANIMATIONEX_H
#include <Windows.h>
#include "vector"
typedef struct AnimateU{
	int		start;
	int		tempstart;
	int	    end;
	float   time;
	DWORD dwTime;
	int    max;
	int		x;
	int    y;
}_TempAnimate;
class cAnimationEx 
{
	_TempAnimate			m_An;
	std::vector<HBITMAP> v_map;
	std::vector<HDC>  v_dc;
	std::vector<_TempAnimate> v_An;
public:
	cAnimationEx();
	~cAnimationEx();

public:

	void InitAnimationEx(HDC _hdc,HINSTANCE _hInst,int _number,const char* _teg,int _max,int _x ,int _y,int _start,int _end,float _time);
	void DrawAnimationEx(HDC _hdc,int _number,int _x,int _y);
	void DrawAnimationEx(HDC _hdc,int _number,int _x,int _y,UINT _rgb);
	
	void SetTime(int _number,float _time){
		v_An.at(_number).time = _time;
	}
	void setEnd(int _number,int _end){
		v_An.at(_number).end = _end  ;
	}
	void setStart(int _number,int _start){
		v_An.at(_number).tempstart = _start;
	}
	float GetTime(int _number){
		return v_An.at(_number).time;
	}
	int GetEnd(int _number){
		return v_An.at(_number).end;
	}
	int GetStart(int _number){
		return v_An.at(_number).start;
	}
	void First(int _number){
		v_An.at(_number).start = v_An.at(_number).tempstart;
	}
	void MoveScane(int _number,int _move){
		v_An.at(_number).start = _move;
	}
private:
	void TimeCheck(int _number);

};
#endif
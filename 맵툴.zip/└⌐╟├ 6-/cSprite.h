#ifndef _CSPRITE_H
#define _CSPRITE_H
#include <Windows.h>
#include "vector"
typedef struct Imagle{
	const char* teg;
	int			x;
	int			y;
	RECT		rect;
}imagle;
class cSprite 
{
	imagle m_im;
	std::vector<imagle> v_im;
	std::vector<HBITMAP> v_map;
	std::vector<HDC>  v_dc;


public:
	cSprite();
	~cSprite();

public:

	void Draw(HDC _hdc,int _number,int _x,int _y);
	void Draw(HDC _hdc,int _number,int _x,int _y,int _w ,int _h);

	void Draw(HDC _hdc,int _number,int _x, int _y,UINT _rgb);
	void Draw(HDC _hdc,int _number,int _x,int _y,int _w,int _h,UINT _rgb);

	void DrawAlp(HDC _hdc ,int _number ,int _x,int _y , UINT _alp);
	void DrawAlp(HDC _hdc ,int _number ,int _x,int _y ,UINT _rgb, UINT _alp);

	void InitSprite(HDC _hdc,HINSTANCE _hInst,int _number,const char* _teg,int _x ,int _y);
	void SetRect(int _number,int _left,int _top,int _right,int _bottom){
		v_im.at(_number).rect.top = _top;
		v_im.at(_number).rect.bottom = _bottom;
		v_im.at(_number).rect.right = _right;
		v_im.at(_number).rect.left = _left;
	}
	RECT GetRect(int _number){
		return v_im.at(_number).rect;
	}
	HDC GetImagleDc(int _number);
	imagle GetImagle(int _number);
private:

};
#endif
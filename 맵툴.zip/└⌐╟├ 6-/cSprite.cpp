#include "cSprite.h"

cSprite::cSprite()
{

}
cSprite::~cSprite()
{
	for(int i =0 ; i < v_dc.size();i++)
	{
		DeleteDC(v_dc.at(i));

	}
	v_dc.clear();
	v_im.clear();
	v_map.clear();

}
void cSprite::InitSprite(HDC _hdc,HINSTANCE _hInst,int _number,const char* _teg,int _x ,int _y)
{
	
	m_im.teg = _teg;
	m_im.x   = _x;
	m_im.y   = _y;
	m_im.rect.left = 0;
	m_im.rect.top = 0;
	m_im.rect.bottom = _y;
	m_im.rect.right = _x;
	v_im.push_back(m_im);
	v_map.push_back((HBITMAP)LoadImage(_hInst,v_im.at(_number).teg,IMAGE_BITMAP,0,0,LR_LOADFROMFILE));
	v_dc.push_back(CreateCompatibleDC(_hdc));

	SelectObject(v_dc.at(_number),v_map.at(_number));

}


void cSprite::DrawAlp(HDC _hdc ,int _number ,int _x,int _y , UINT _alp)
{
	imagle im = v_im.at(_number);
	BLENDFUNCTION bf;
	bf.BlendOp=AC_SRC_OVER; 
	bf.BlendFlags=0; 
	bf.SourceConstantAlpha=_alp; 
	bf.AlphaFormat=0;

	AlphaBlend(_hdc, _x, _y, im.x,im.y,
		v_dc.at(_number), 0, 0, v_im.at(_number).x,v_im.at(_number).y, bf);
}

void cSprite::Draw(HDC _hdc,int _number,int _x, int _y,UINT _rgb)
{	
	imagle im = v_im.at(_number);
	

	TransparentBlt(
		_hdc,_x,_y,im.x,im.y,v_dc.at(_number),0,0,im.x,im.y,_rgb); //�̰Ÿ���
	////_����� dc , x  ,y ,x������ ,y������ , ������ dc ,x,y,x������.y������ , ���İ� 
}
void cSprite::Draw(HDC _hdc,int _number,int _x,int _y,int _w,int _h,UINT _rgb)
{
	if(_w - _x < 0 || _h - _y < 0)
		return;
	imagle im = v_im.at(_number);
	TransparentBlt(
		_hdc,_x,_y,_w - _x ,_h - _y,v_dc.at(_number),0,0,im.x,im.y,_rgb); 
}
void cSprite::Draw(HDC _hdc,int _number,int _x,int _y)
{
	BitBlt(_hdc,_x,_y,v_im.at(_number).x,v_im.at(_number).y,v_dc.at(_number),0,0,SRCCOPY);	

}
void cSprite::Draw(HDC _hdc,int _number,int _x,int _y,int _w , int _h)
{
	if(_w - _x < 0 || _h - _y < 0)
		return;
	StretchBlt(_hdc,_x,_y,_w - _x,_h - _y,v_dc.at(_number),0,0,v_im.at(_number).x,v_im.at(_number).y,SRCCOPY);
	//BitBlt(_hdc,_x,_y,_w,_h,v_dc.at(_number),0,0,SRCCOPY);	
}



HDC cSprite::GetImagleDc(int _number)
{
	return v_dc.at(_number);
}
imagle cSprite::GetImagle(int _number)
{
	return v_im.at(_number);
}
